package in.kashyapbhat.filmibeein_v_1;

import android.content.Context;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

/**
 * Filmibeein_V_1 Created by KashyapBhat on 10-02-2018.
 */

public class Connecter {
    public static Object Connecter(String URLAddress){
     try{
         URL url =new URL(URLAddress);
         HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

         httpURLConnection.setRequestMethod("GET");
         httpURLConnection.setConnectTimeout(15000);
         httpURLConnection.setReadTimeout(15000);
         httpURLConnection.setDoInput(true);

         return httpURLConnection;
     }

     catch (Exception e)
     {
         e.printStackTrace();
         return "Connection Error";
     }

    }


}