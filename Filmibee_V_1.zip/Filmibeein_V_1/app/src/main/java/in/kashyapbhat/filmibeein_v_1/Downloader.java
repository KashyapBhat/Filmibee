package in.kashyapbhat.filmibeein_v_1;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;

/**
 * Filmibeein_V_1 Created by KashyapBhat on 11-02-2018.
 */

public class Downloader extends AsyncTask{
Context c;
String urlAddress;
RecyclerView rv;
ProgressDialog pd;
    public Downloader(Context c, String urlAddress, RecyclerView rv)
    {
        this.c=c;
        this.urlAddress = urlAddress;
        this.rv = rv;

    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        pd= new ProgressDialog(c);
        pd.setTitle("Fetching Articles");
        pd.setMessage("Fetching, Please Wait ... ");
        pd.show();
    }

    @Override
    protected Object doInBackground(Object[] objects) {
        return downloadData();
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);
        pd.dismiss();
        if(o.toString().startsWith("Error"))
        {
            Toast.makeText(c, o.toString(), Toast.LENGTH_SHORT).show();
        }else {
//PARSE
            new RSSParser(c, (InputStream) o,rv).execute();
        }
    }

    private Object downloadData()
    {
        Object connection = Connecter.Connecter(urlAddress);
        if(connection.toString().startsWith("Error")){
            return connection.toString();
        }

        try
        {
            HttpURLConnection urlConnection = (HttpURLConnection)connection;
            int ResCode =urlConnection.getResponseCode();
            if(ResCode == urlConnection.HTTP_OK)
            {
                InputStream is = new BufferedInputStream(urlConnection.getInputStream());
                return is;

            }
            return "Connection Error";
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return "Connection Error";
        }
    }

}
