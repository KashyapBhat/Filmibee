package in.kashyapbhat.filmibeein_v_1;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Filmibeein_V_1 Created by KashyapBhat on 11-02-2018.
 */


public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {

    Context c;
    ArrayList<Article> articles;

    public MyAdapter(Context c, ArrayList<Article> articles) {
        this.c = c;
        this.articles = articles;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(c).inflate(R.layout.model,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {

        Article article=articles.get(position);

        String title=article.getTitle();
        String desc=article.getDescription();
        String date=article.getDate();
        String imageUrl=article.getImageUrl().replace("localhost","10.0.2.2");

        holder.titleTxt.setText(title);
        holder.desctxt.setText(desc.substring(0,130));
        holder.dateTxt.setText(date);
        Picasso.with(c).load(imageUrl.toString()).into(holder.img);

    }

    @Override
    public int getItemCount() {
        return articles.size();
    }
}